import { useState, useEffect } from 'react';

function Dashboard({ user }) {
  const [activeTab, setActiveTab] = useState('books');
  const [books, setBooks] = useState([]);
  const [members, setMembers] = useState([]);
  const [transactions, setTransactions] = useState([]);

  // Mock data - Replace with API calls
  useEffect(() => {
    // Mock books data
    const mockBooks = [
      { id: 1, title: 'The Great Gatsby', author: 'F. Scott Fitzgerald', isbn: '9780743273565', status: 'Available' },
      { id: 2, title: 'To Kill a Mockingbird', author: 'Harper Lee', isbn: '9780061120084', status: 'Borrowed' },
      { id: 3, title: '1984', author: 'George Orwell', isbn: '9780451524935', status: 'Available' },
      { id: 4, title: 'Pride and Prejudice', author: 'Jane Austen', isbn: '9780141439518', status: 'Available' },
    ];

    // Mock members data
    const mockMembers = [
      { id: 1, name: 'John Doe', email: 'john@example.com', membership: 'Gold', booksBorrowed: 2 },
      { id: 2, name: 'Jane Smith', email: 'jane@example.com', membership: 'Silver', booksBorrowed: 1 },
    ];

    // Mock transactions data
    const mockTransactions = [
      { id: 1, book: 'The Great Gatsby', member: 'John Doe', date: '2024-01-15', type: 'Borrow', dueDate: '2024-02-15' },
      { id: 2, book: 'To Kill a Mockingbird', member: 'Jane Smith', date: '2024-01-10', type: 'Borrow', dueDate: '2024-02-10' },
    ];

    setBooks(mockBooks);
    setMembers(mockMembers);
    setTransactions(mockTransactions);
  }, []);

  const stats = {
    totalBooks: books.length,
    availableBooks: books.filter(b => b.status === 'Available').length,
    totalMembers: members.length,
    activeTransactions: transactions.length
  };

  return (
    <div className="dashboard">
      <div className="dashboard-header">
        <h1>Library Dashboard</h1>
        <p>Welcome back, {user?.name}</p>
      </div>

      {/* Stats Cards */}
      <div className="stats-grid">
        <div className="stat-card card">
          <h3>Total Books</h3>
          <p className="stat-number">{stats.totalBooks}</p>
        </div>
        <div className="stat-card card">
          <h3>Available Books</h3>
          <p className="stat-number">{stats.availableBooks}</p>
        </div>
        <div className="stat-card card">
          <h3>Total Members</h3>
          <p className="stat-number">{stats.totalMembers}</p>
        </div>
        <div className="stat-card card">
          <h3>Active Transactions</h3>
          <p className="stat-number">{stats.activeTransactions}</p>
        </div>
      </div>

      {/* Tabs */}
      <div className="dashboard-tabs">
        <button 
          className={`tab-btn ${activeTab === 'books' ? 'active' : ''}`}
          onClick={() => setActiveTab('books')}
        >
          Books
        </button>
        <button 
          className={`tab-btn ${activeTab === 'members' ? 'active' : ''}`}
          onClick={() => setActiveTab('members')}
        >
          Members
        </button>
        <button 
          className={`tab-btn ${activeTab === 'transactions' ? 'active' : ''}`}
          onClick={() => setActiveTab('transactions')}
        >
          Transactions
        </button>
      </div>

      {/* Tab Content */}
      <div className="tab-content card">
        {activeTab === 'books' && (
          <div className="books-section">
            <div className="section-header">
              <h2>Book Management</h2>
              <button className="btn btn-primary">Add New Book</button>
            </div>
            <table className="data-table">
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Title</th>
                  <th>Author</th>
                  <th>ISBN</th>
                  <th>Status</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {books.map(book => (
                  <tr key={book.id}>
                    <td>{book.id}</td>
                    <td>{book.title}</td>
                    <td>{book.author}</td>
                    <td>{book.isbn}</td>
                    <td>
                      <span className={`status-badge ${book.status.toLowerCase()}`}>
                        {book.status}
                      </span>
                    </td>
                    <td>
                      <button className="btn-action">Edit</button>
                      <button className="btn-action delete">Delete</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {activeTab === 'members' && (
          <div className="members-section">
            <div className="section-header">
              <h2>Member Management</h2>
              <button className="btn btn-primary">Add New Member</button>
            </div>
            <table className="data-table">
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Name</th>
                  <th>Email</th>
                  <th>Membership</th>
                  <th>Books Borrowed</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {members.map(member => (
                  <tr key={member.id}>
                    <td>{member.id}</td>
                    <td>{member.name}</td>
                    <td>{member.email}</td>
                    <td>{member.membership}</td>
                    <td>{member.booksBorrowed}</td>
                    <td>
                      <button className="btn-action">Edit</button>
                      <button className="btn-action delete">Delete</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {activeTab === 'transactions' && (
          <div className="transactions-section">
            <div className="section-header">
              <h2>Transaction History</h2>
              <button className="btn btn-primary">New Transaction</button>
            </div>
            <table className="data-table">
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Book</th>
                  <th>Member</th>
                  <th>Date</th>
                  <th>Type</th>
                  <th>Due Date</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {transactions.map(transaction => (
                  <tr key={transaction.id}>
                    <td>{transaction.id}</td>
                    <td>{transaction.book}</td>
                    <td>{transaction.member}</td>
                    <td>{transaction.date}</td>
                    <td>
                      <span className={`type-badge ${transaction.type.toLowerCase()}`}>
                        {transaction.type}
                      </span>
                    </td>
                    <td>{transaction.dueDate}</td>
                    <td>
                      <button className="btn-action">Return</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}

export default Dashboard;