import { Link } from 'react-router-dom';

function Home() {
  return (
    <div className="home">
      <section className="hero">
        <div className="hero-content">
          <h1>Welcome to Library Management System</h1>
          <p>Efficiently manage books, members, and transactions</p>
          <div className="hero-buttons">
            <Link to="/signup" className="btn btn-primary">Get Started</Link>
            <Link to="/login" className="btn btn-secondary">Login</Link>
          </div>
        </div>
      </section>

      <section className="features">
        <h2 className="text-center">Features</h2>
        <div className="features-grid">
          <div className="feature-card card">
            <h3>📖 Book Management</h3>
            <p>Add, edit, and manage your book collection with ease</p>
          </div>
          <div className="feature-card card">
            <h3>👥 Member Management</h3>
            <p>Track members and their borrowing history</p>
          </div>
          <div className="feature-card card">
            <h3>🔄 Transactions</h3>
            <p>Manage book checkouts, returns, and fines</p>
          </div>
          <div className="feature-card card">
            <h3>📊 Reports</h3>
            <p>Generate detailed reports and analytics</p>
          </div>
        </div>
      </section>
    </div>
  );
}

export default Home;