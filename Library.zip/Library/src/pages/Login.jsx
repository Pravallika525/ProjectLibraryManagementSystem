import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';

function Login({ onLogin }) {
  const [formData, setFormData] = useState({
    email: '',
    password: ''
  });
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setError('');

    // Mock authentication - Replace with actual API call
    if (formData.email === 'admin@library.com' && formData.password === 'password') {
      const userData = {
        id: 1,
        name: 'Admin User',
        email: formData.email,
        role: 'admin'
      };
      const token = 'mock-jwt-token';
      onLogin(userData, token);
      navigate('/dashboard');
    } else {
      setError('Invalid credentials. Try admin@library.com / password');
    }
  };

  return (
    <div className="auth-container">
      <div className="auth-card card">
        <h2 className="text-center">Login</h2>
        
        {error && <div className="alert alert-danger">{error}</div>}
        
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label>Email</label>
            <input
              type="email"
              name="email"
              className="form-control"
              value={formData.email}
              onChange={handleChange}
              required
            />
          </div>
          
          <div className="form-group">
            <label>Password</label>
            <input
              type="password"
              name="password"
              className="form-control"
              value={formData.password}
              onChange={handleChange}
              required
            />
          </div>
          
          <button type="submit" className="btn btn-primary btn-block">
            Login
          </button>
        </form>
        
        <div className="auth-links">
          <p>Don't have an account? <Link to="/signup">Sign up here</Link></p>
        </div>
        
        <div className="demo-credentials">
          <p><strong>Demo Credentials:</strong></p>
          <p>Email: admin@library.com</p>
          <p>Password: password</p>
        </div>
      </div>
    </div>
  );
}

export default Login;